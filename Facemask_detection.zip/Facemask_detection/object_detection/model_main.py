# Copyright 2017 The TensorFlow Authors. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Binary to run train and evaluation on object detection model."""

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import argparse
import tensorflow as tf

from object_detection import model_hparams
from object_detection import model_lib
from object_detection import Write_file


def main(unused_argv):
  config = tf.estimator.RunConfig(model_dir=model_dir)
  pipeline_config_path=Write_file.write_pipeline(pipeline_config_path,checkpoint_dir,train,test,label_map,batch_size,num_classes,num_steps)
  config = tf.estimator.RunConfig(model_dir=model_dir)

  train_and_eval_dict = model_lib.create_estimator_and_inputs(
      run_config=config,
      hparams=model_hparams.create_hparams(hparams_overrides),
      pipeline_config_path=pipeline_config_path,
      train_steps=num_steps,
      sample_1_of_n_eval_examples=sample_1_of_n_eval_examples,
      sample_1_of_n_eval_on_train_examples=(
          sample_1_of_n_eval_on_train_examples))
  estimator = train_and_eval_dict['estimator']
  train_input_fn = train_and_eval_dict['train_input_fn']
  eval_input_fns = train_and_eval_dict['eval_input_fns']
  eval_on_train_input_fn = train_and_eval_dict['eval_on_train_input_fn']
  predict_input_fn = train_and_eval_dict['predict_input_fn']
  train_steps = train_and_eval_dict['train_steps']

  if checkpoint_dir:
    if eval_training_data:
      name = 'training_data'
      input_fn = eval_on_train_input_fn
    else:
      name = 'validation_data'
      # The first eval input will be evaluated.
      input_fn = eval_input_fns[0]
    if run_once:
      estimator.evaluate(input_fn,
                         num_eval_steps=None,
                         checkpoint_path=tf.train.latest_checkpoint(
                             checkpoint_dir))
    else:
      model_lib.continuous_eval(estimator, checkpoint_dir, input_fn,
                                train_steps, name)
  else:
    train_spec, eval_specs = model_lib.create_train_and_eval_specs(
        train_input_fn,
        eval_input_fns,
        eval_on_train_input_fn,
        predict_input_fn,
        train_steps,
        eval_on_train_data=False)

    # Currently only a single Eval Spec is allowed.
    tf.estimator.train_and_evaluate(estimator, train_spec, eval_specs[0])


if __name__ == '__main__':
  parser = argparse.ArgumentParser()
  parser.add_argument(
      '--pipeline_config_path',
      type=str,
      default='/opt/ml/model/pipeline.config',
      help='Path to pipeline in downloaded model.'
  )
  parser.add_argument(
      '--train', 
      type=str, 
      default='/opt/ml/input/data/training'
      )
  parser.add_argument(
      '--test', 
      type=str, 
      default='/opt/ml/input/data/testing'
      )
  parser.add_argument(
      '--eval_training_data',
      type=bool,
      default=False,
      help='If training data should be evaluated for this job. Note '
                     'that one call only use this in eval-only mode, and '
                     '`checkpoint_dir` must be supplied.'
  )
  parser.add_argument(
      '--sample_1_of_n_eval_examplesr',
      type=int,
      default=1',
      help='Will sample one of every n eval input examples, where n is provided.'
  )
  parser.add_argument(
      '--hparams_overrides',
      type=str,
      default=None,
      help='Hyperparameter overrides represented as a string containing comma-separated hparam_name=value pairs.'
  )
  parser.add_argument(
      '--output_labels',
      type=str,
      default='/opt/ml/model/output_labels.txt',
      help='Where to save the trained graph\'s labels.'
  )
  parser.add_argument(
      '--summaries_dir',
      type=str,
      default='/tmp/retrain_logs',
      help='Where to save summary logs for TensorBoard.'
  )
  parser.add_argument(
      '--num_steps',
      type=int,
      default=400,
      help='How many training steps to run before ending.'
  )
  parser.add_argument(
      '--learning_rate',
      type=float,
      default=0.01,
      help='How large a learning rate to use when training.'
  )
  parser.add_argument(
      '--num_classes',
      type=int,
      default=2,
      help='What percentage of images to use as a test set.'
  )
  parser.add_argument(
      '--checkpoint_dir',
      type=int,
      default='/opt/ml/model/checkpoint',
      help='What percentage of images to use as a validation set.'
  )
  parser.add_argument(
      '--label_map',
      default="/opt/ml/object_detection/label_map.pbtxt",
      help="""\
      Whether to print out a list of all misclassified test images.\
      """,
      action='store_true'
  )
  parser.add_argument(
      '--model_dir',
      type=str,
      default='/tmp/imagenet',
      help="""\
      Path to classify_image_graph_def.pb,
      imagenet_synset_to_human_label_map.txt, and
      imagenet_2012_challenge_label_map_proto.pbtxt.\
      """
  )
  parser.add_argument(
      '--run_once',
      type=bool,
      default=False,
      help='If running in eval-only mode, whether to run just one round of eval vs running continuously (default).'
  )
  FLAGS, unparsed = parser.parse_known_args()
  tf.app.run(main=main, argv=["/opt/ml/input/data/train/"] + unparsed)
